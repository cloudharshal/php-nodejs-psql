<?php
define('API_URL', 'http://13.233.86.25:5000/api');
?>

