document.addEventListener("DOMContentLoaded", function () {
    fetch('http://13.233.86.25:5000/api/cars') // Update with your API URL
        .then(response => response.json())
        .then(data => {
            console.log("API Response:", data); // Debugging

            let carList = document.getElementById("car-list");
            if (!carList) {
                console.error("car-list element not found!");
                return;
            }

            if (data.length === 0) {
                carList.innerHTML = '<p class="text-center">No cars available.</p>';
            } else {
                carList.innerHTML = data.map(car => `
                    <div class="col-md-4">
                        <div class="car-card card mb-4">
                            <img src="${car.image || 'https://via.placeholder.com/300'}" alt="${car.model}" class="car-img">
                            <div class="card-body">
                                <h5 class="card-title">${car.brand} ${car.model}</h5>
                                <p class="card-text">Year: ${car.year}</p>
                                <p class="card-text">Price: $${car.price}/day</p>
                                <a href="book.php?car_id=${car.id}" class="btn btn-primary">Book Now</a>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        })
        .catch(error => console.error("Error fetching cars:", error));
});

