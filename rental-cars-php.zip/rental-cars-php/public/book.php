<?php
include '../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $carId = $_POST['car_id'];
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];

    $postData = json_encode([
        "carId" => $carId,
        "startDate" => $startDate,
        "endDate" => $endDate
    ]);

    $ch = curl_init(API_URL . "/bookings");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $response = curl_exec($ch);
    curl_close($ch);

    header("Location: index.php?message=Booking successful!");
    exit();
}

$carId = $_GET['car_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Car</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <?php include '../templates/header.php'; ?>

    <h1>Book a Car</h1>
    <form action="book.php" method="POST">
        <input type="hidden" name="car_id" value="<?= $carId ?>">
        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" required>
        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" required>
        <button type="submit">Book Now</button>
    </form>

    <?php include '../templates/footer.php'; ?>
</body>
</html>

