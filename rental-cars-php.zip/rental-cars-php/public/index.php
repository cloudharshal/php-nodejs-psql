<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .car-card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        .car-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center">Car Rental System</h1>
        <div id="car-list" class="row mt-4"></div>
    </div>

    <script>
        fetch('http://13.233.86.25:5000/api/cars') // Update with your actual API URL
        .then(response => response.json())
        .then(data => {
            let carList = document.getElementById('car-list');
            carList.innerHTML = '';

            data.forEach(car => {
                let carHtml = `
                    <div class="col-md-4">
                        <div class="car-card card mb-4">
                            <img src="${car.image || 'https://via.placeholder.com/300'}" alt="${car.model}" class="car-img">
                            <div class="card-body">
                                <h5 class="card-title">${car.brand} ${car.model}</h5>
                                <p class="card-text">Year: ${car.year}</p>
                                <p class="card-text">Price: $${car.price}/day</p>
                                <a href="#" class="btn btn-primary">Book Now</a>
                            </div>
                        </div>
                    </div>`;
                carList.innerHTML += carHtml;
            });
        })
        .catch(error => console.error('Error fetching cars:', error));
	</script>
</body>
</html>

