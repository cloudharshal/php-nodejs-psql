<?php
include '../config/config.php';

$carId = $_GET['id'];
$apiUrl = API_URL . "/cars/" . $carId;
$response = file_get_contents($apiUrl);
$car = json_decode($response, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $car['name'] ?> Details</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <?php include '../templates/header.php'; ?>

    <div class="car-details">
        <img src="<?= $car['image_url'] ?>" alt="<?= $car['name'] ?>">
        <h1><?= $car['name'] ?> - <?= $car['model'] ?></h1>
        <p>Price per day: $<?= $car['price_per_day'] ?></p>
        <a href="book.php?car_id=<?= $car['id'] ?>">Book Now</a>
    </div>

    <?php include '../templates/footer.php'; ?>
</body>
</html>

