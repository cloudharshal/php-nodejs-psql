<header>
    <h1>Rental Cars</h1>
    <nav>
        <a href="index.php">Home</a>
    </nav>
</header>

