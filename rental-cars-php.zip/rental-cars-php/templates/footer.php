<footer>
    <p>© 2024 Rental Cars. All rights reserved.</p>
</footer>

