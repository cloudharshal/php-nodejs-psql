const express = require('express');
const Car = require('../models/Car');
const router = express.Router();

// Get all cars
router.get('/', async (req, res) => {
    const cars = await Car.findAll();
    res.json(cars);
});

// Add new car
router.post('/', async (req, res) => {
    const { name, model, pricePerDay, imageUrl } = req.body;
    const car = await Car.create({ name, model, pricePerDay, imageUrl });
    res.json(car);
});

module.exports = router;

