const express = require('express');
const Booking = require('../models/Booking');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Get all bookings
router.get('/', authMiddleware, async (req, res) => {
    const bookings = await Booking.findAll({ include: ['User', 'Car'] });
    res.json(bookings);
});

// Create booking
router.post('/', authMiddleware, async (req, res) => {
    const { carId, startDate, endDate } = req.body;
    const booking = await Booking.create({ userId: req.user.id, carId, startDate, endDate });
    res.json(booking);
});

module.exports = router;

